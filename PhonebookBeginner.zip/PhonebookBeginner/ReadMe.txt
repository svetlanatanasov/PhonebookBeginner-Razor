For this task, I decided to use ASP.NET Core 2.0 MVC with Razor Page.

Requirements:
	.NET Core 2.0 � download from http://dot.net/
	Newtonsoft.Json � should be loaded automatically when building the project.


I am using Visual Studio, but you can also build and run the project by command-line interface tools - https://docs.microsoft.com/en-us/dotnet/core/tools/?tabs=netcore2x
